package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@SpringBootApplication
public class EmployeeBackendApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeBackendApplication.class, args);
	}
	@Autowired
	EmployeeRepository repository;
	
	@Override
	public void run(String... args)throws Exception
	{
		this.repository.save(new Employee("ss","e1","ms","Asap"));
		this.repository.save(new Employee("shs","e2","mye","@mail.com"));
		this.repository.save(new Employee("as","e3","js","@gmail.com"));

	}
}

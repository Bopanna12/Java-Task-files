package Springdayone;

public class Student {

}

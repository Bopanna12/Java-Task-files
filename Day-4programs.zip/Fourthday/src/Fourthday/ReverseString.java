package Fourthday;

public class ReverseString {
	 public static void main(String[] args) {    
	        String s= "Welcome";    
	        String revStr = "";    
	            for(int i = s.length()-1; i >= 0; i--){    
	            revStr = revStr + s.charAt(i);    
	        }    
	            
	        System.out.println("Original string: " + s);    
	        System.out.println("Reverse of the  string is: " + revStr);    
	    }    

}

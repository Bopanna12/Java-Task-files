package Fourthday;

import java.util.Scanner;

public class SwapTwono {
	  public static void main(String[] args)
	   {
	      int a, b, temp;
	      Scanner sw = new Scanner(System.in);
	      System.out.print("Enter the First No: ");
	      a = sw.nextInt();
	      System.out.print("Enter the Second No: ");
	      b = sw.nextInt();
	      temp = a;
	      a = b;
	      b = temp;
	      System.out.println("reverse  no:= " +a);
	      System.out.println("reverse no := " +b);
	   }

}

package Fourthday;

public class Ascii {
	public static void main(String arg[]) {
		char p;
		int i;
		for(i=65;i<=90;i++)
		{
			p=(char)i;
			System.out.println(i+"="+p);
					
		}
	}

}

package Fourthday;

import java.util.Scanner;

public class Interfaceex {
	public static void main(String arg[]) {
	Mahindra m=new Mahindra();
	m.tuneUpCost();
	m.canCarry(5);
	
}
}

interface IVehicle {
   
    public double tuneUpCost();
    public boolean canCarry(int numPassengers);
  }
class Mahindra implements IVehicle{

	@Override
	public double tuneUpCost() {
		System.out.println("The tune up cost is 6731");
		return 0;
	}

	@Override
	public boolean canCarry(int numPassengers) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the no of passengers");
		if (numPassengers<=6) {
			System.out.println("the vehicle can hold the given no of pass");
		}
		else {
			System.out.println("the vehicle cannot hold the given no of pass");

		}
		return false;
	}
	
}

abstract class Animal {
	  abstract void makeSound();

	  public void eat() {
	   //add code


	  }
	}


package Fourthday;

import java.util.Scanner;

public class Power {
	public static void main(String arg[]) {
	int m=5,n=3,x=1;
	System.out.println(n+"the raised power"+m+"is:");
	while(m>0) {
		x=x*n;
		m--;
	}
	System.out.print(x);
}
}



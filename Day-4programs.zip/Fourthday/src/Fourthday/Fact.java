package Fourthday;

import java.util.Scanner;

public class Fact {
	public static void main(String arg[]) {
		int num,factorial=1,i;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter an Integer");
		num=sc.nextInt();
		factorial=fact(num);
		System.out.println("the factorial is ="+factorial);
		
	}
	public static int fact(int num) {
		if(num<=1)
			return 1;
		return num*fact(num-1);
	}

}

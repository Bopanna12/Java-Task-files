package Fourthday;

public class Abstractex2 {
	public static void main(String args[]) {
		Tvs t=new Tvs();
		Bmw b=new Bmw();
		t.brake();
		b.brake();
	}

}
abstract class MotorBike {
	  abstract void brake();//this is abstract method
	}
class Tvs extends MotorBike{

	@Override
	void brake() {
		System.out.println("Break is Conditionally working");
	}
	
	
}
class Bmw extends MotorBike{

	@Override
	void brake() {
		System.out.println("Break is Conditionally working and here abs is functionally woring great");

	}
	
}
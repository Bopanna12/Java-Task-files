package Fourthday;

import java.util.Scanner;

public class CountOccurance {
	public static void main(String arg[]) {
	Scanner co=new Scanner(System.in);
	Scanner oc=new Scanner(System.in);
	System.out.println("enter the String ");
	String s=co.next();
	System.out.println("enter the character to be counted");
	char p=oc.next().charAt(0);
	int count=0;
	try {
	for(int i=0;i<=s.length();i++) {
		if(s.charAt(i)==p) {
			count++;
		}
	}
	}
	catch(Exception e) {
		System.out.println("this msg is for handling the array index out of bound exception");
	}
	System.out.println("the total no of repeated char is :"+count);
	}
}

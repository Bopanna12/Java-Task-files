package Fourthday;

public class MyClassInterface  {
	public static void main(String arg[]) {
		Myclass m=new Myclass();
		m.method1();
		m.method2();
	}
	
}
interface A{
	void method1();
	void method2();
}
class Myclass implements A{

	@Override
	public void method1() {
		System.out.println("this is method 1");
	
		
	}

	@Override
	public void method2() {
		System.out.println("this is method 2");
		
		
	}
	
	
}

package Fourthday;

import java.util.Scanner;

public class Abstrctex {
	public static void main(String arg[]) {
		Sound sp=new Sound();
		sp.makeSound();
		sp.eat();
	}
	

}
abstract class Animal {
	  abstract void makeSound();//abstract method

	  public void eat() {  //this is non abstract method 
	   //add code
		  int n;
		  System.out.println("enter the animal no that is specified /n1.Horse/n2.tiger");
		  Scanner s=new Scanner(System.in);
		  n=s.nextInt();
		  if(n==1) {
			  System.out.println("Eats Grass");
		  }
		  else {
			  System.out.println("Eats flesh");
		  }
		 }
	}
class Sound extends Animal{

	@Override
	void makeSound() {
		System.out.println("Animals do make sound");
	}
	
}

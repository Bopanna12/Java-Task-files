package Seventh;

import java.util.HashMap;
import java.util.Map;

public class HashMapMethods {
	public static void main(String arg[]) {
		HashMap<String,String> hash=new HashMap<>();
		hash.put("clr1","Red");
		hash.put("clr2","Black");
		hash.put("clr3","Pink");
		hash.put("clr4","Green");
		System.out.println(hash.containsKey("clr4"));
		
		hash.put("clr1","Red");
		hash.put("clr2","Black");
		hash.put("clr3","Pink");
		hash.put("clr4","Green");
		System.out.println(hash.size());

		
		System.out.println(hash);
		
		hash.put("clr1","Red");
		hash.put("clr2","Black");
		hash.put("clr3","Pink");
		hash.put("clr4","Green");
		hash.replace("clr2", "yellow");
		System.out.println(hash);
		
		hash.remove("clr3");
		System.out.println(hash);
		System.out.println(hash.get("color1"));


		hash.clear();
		System.out.println(hash.isEmpty());
		for(Map.Entry<String,String> m:hash.entrySet()) {
			System.out.println("the keys are:"+m.getKey()+"values are:"+m.getValue());
		}
	}
}

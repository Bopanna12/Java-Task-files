package Seventh;

import java.util.HashMap;
import java.util.Map;

public class HashMapobTask1 {
	public static void main(String arg[]) {
		HashMap<Integer,Book> bk=new HashMap<>();
		Book b1=new Book("Bopanna","b53",894);
		Book b2=new Book("Bopanna","b53",894);
		Book b3=new Book("Bopanna","b53",894);
		Book b4=new Book("Bopanna","b53",894);
		bk.put(1, b1);
		bk.put(4, b2);
		bk.put(3, b3);
		bk.put(2, b4);

		System.out.println(bk);
		for(Map.Entry<Integer,Book> bo:bk.entrySet()) {
			System.out.println("the key is"+bo.getKey()+"the name is:"+bo.getValue().name+"the id is:"+bo.getValue().id+"the price is:"+bo.getValue().price);
		}
		
	}
}
class Book{
	String name,id;
	int price;
	public Book(String name, String id, int price) {
		super();
		this.name = name;
		this.id = id;
		this.price = price;
	}
}
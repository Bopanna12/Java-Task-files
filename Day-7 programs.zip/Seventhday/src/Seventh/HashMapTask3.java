package Seventh;

import java.util.HashMap;
import java.util.Map;

public class HashMapTask3 {
	public static void main(String arg[]) {
		HashMap<Integer,String> hash=new HashMap<>();
		hash.put(1,"Bopanna");
		hash.put(2,"Muthanna");
		hash.put(3,"Pink");
		hash.put(4,"Green");
		System.out.println(hash);
		for(Map.Entry<Integer,String> m:hash.entrySet()) {
			System.out.println("the keys are:"+m.getKey()+"Names are:"+m.getValue());
		}
	}
}

package Seventh;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListCategorise {
	public static void main(String arg[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the length");
		int le=sc.nextInt();
		ArrayList<Integer> arr=new ArrayList<>();
		ArrayList<Integer> even=new ArrayList<>();
		ArrayList<Integer> odd=new ArrayList<>();
		ArrayList<Integer> prime=new ArrayList<>();
		

		System.out.println("Enter the elements to be categorised :");
		int ele = 0;
		for(int i=0;i<le;i++) {
			 ele=sc.nextInt();
			 arr.add(ele);
			
		}
		
		System.out.println("the elements are :"+arr);
		
		for(int i=0;i<le;i++) {
			int val=arr.get(i);
			if(val%2==0) {
				even.add(val);
				
			}
			else {
				odd.add(val);
			}
			
		}
		for(int i=0;i<le;i++) {
			int val=arr.get(i);
			if(val==2) {
				prime.add(val);
			}
			else if(val%2==1 && val%val==0 ) {
				prime.add(val);
			}
			else {
				
			}
			
		}
		System.out.println("the even list is :"+even);
		System.out.println("the odd list is :"+odd);
		System.out.println("the prime list is:"+prime);
		
	}
}

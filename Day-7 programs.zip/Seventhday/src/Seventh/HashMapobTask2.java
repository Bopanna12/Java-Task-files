package Seventh;

import java.util.HashMap;
import java.util.Map;

public class HashMapobTask2 {
	public static void main(String arg[]) {
		HashMap<Integer,Employee> em=new HashMap<>();
		Employee b1=new Employee("Bopanna","b53",89444);
		Employee b2=new Employee("Muthanna","b54",89444);
		Employee b3=new Employee("nowshad","b52",89444);
		Employee b4=new Employee("yashu","b51",89444);
		em.put(1, b1);
		em.put(4, b2);
		em.put(3, b3);
		em.put(2, b4);

		System.out.println(em);
		for(Map.Entry<Integer,Employee> bo:em.entrySet()) {
			System.out.println("the key is"+bo.getKey()+"the name is:"+bo.getValue().name+"the id is:"+bo.getValue().id+"the price is:"+bo.getValue().Salary);
		}
		
	}
}
class Employee{
	String name,id;
	int Salary;
	public Employee(String name, String id, int Salary) {
		super();
		this.name = name;
		this.id = id;
		this.Salary=Salary;
	}
}

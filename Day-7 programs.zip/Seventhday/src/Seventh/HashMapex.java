package Seventh;

import java.util.HashMap;
import java.util.Map;

public class HashMapex {
	public static void main(String arg[]) {
		HashMap<String,String> hash=new HashMap<>();
		hash.put("color1","Red");
		hash.put("color2","Black");
		hash.put("color3","Pink");
		hash.put("color4","Green");
		System.out.println(hash);
		for(Map.Entry<String,String> m:hash.entrySet()) {
			System.out.println("the keys are:"+m.getKey()+"values are:"+m.getValue());
		}
	}
}
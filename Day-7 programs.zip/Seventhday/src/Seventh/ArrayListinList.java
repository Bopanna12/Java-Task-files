package Seventh;

import java.util.ArrayList;

public class ArrayListinList {
	
	public static void main(String arg[]) {
		ArrayList<String> li=new ArrayList<>();
		li.add("Bopanna");
		li.add("Chandan");
		li.add("Muthanna");
		li.add("Nowshad");
		ArrayList<ArrayList<String>> li2=new ArrayList<>();
		li2.add(li);
		System.out.println(li2);
		ArrayList<String>li3=new ArrayList<>();
		li3.add("bop");
		li3.add("bop");

		li3.add("bop");
		li3.add("bop");
		li2.add(li3);
		System.out.println(li2);

		
		
		

		
	}
}
	
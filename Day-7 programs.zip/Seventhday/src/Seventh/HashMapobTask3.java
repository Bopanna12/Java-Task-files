package Seventh;

import java.util.HashMap;
import java.util.Map;

public class HashMapobTask3 {
	public static void main(String arg[]) {
		HashMap<Integer,Teacher> te=new HashMap<>();
		Teacher t1=new Teacher("sakshi","s467","Java");
		te.put(1, t1);
		for(Map.Entry<Integer,Teacher> t:te.entrySet()) {
			System.out.println(t.getKey()+t.getValue().name+t.getValue().id+t.getValue().classname);
		}
	}
}
class Teacher{														//have to try for user input too
	String name,id,classname;

	public Teacher(String name, String id, String classname) {
		super();
		this.name = name;
		this.id = id;
		this.classname = classname;
	}
	public String toString()
	{
		return "name is:"+name+"id is:"+id+"classname is:"+classname;
		
	}
}

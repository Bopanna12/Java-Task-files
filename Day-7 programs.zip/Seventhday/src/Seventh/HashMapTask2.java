package Seventh;

import java.util.HashMap;
import java.util.Map;

public class HashMapTask2 {
	public static void main(String arg[]) {
		HashMap<String,Integer> hash=new HashMap<>();
		hash.put("Java",78);
		hash.put("android",89);
		hash.put("python",90);
		hash.put("php",74);
		System.out.println(hash);
		for(Map.Entry<String,Integer> m:hash.entrySet()) {
			System.out.println("the keys are:"+m.getKey()+"Score of sub are:"+m.getValue());
		}
	}
}

package Seventh;

import java.util.ArrayList;
import java.util.ListIterator;

public class Iteratorex {
	public static void main(String arg[]) {
		ArrayList<String> arr=new ArrayList<>();
		arr.add("hello");
		arr.add("good night");

		arr.add("bye");
		arr.add("hi");
		System.out.println(arr);
		ListIterator a=arr.listIterator();
		while(a.hasPrevious()) {
			System.out.println(a.previous());
		}
		while(a.hasNext()) {
			System.out.println(a.next());
		}

	}
}

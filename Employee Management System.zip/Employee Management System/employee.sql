-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2021 at 03:48 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employeeproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `first_name` varchar(20) NOT NULL,
  `middle_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `father_name` varchar(20) NOT NULL,
  `mother_name` varchar(20) NOT NULL,
  `date` varchar(20) NOT NULL,
  `emp_id` varchar(20) NOT NULL,
  `adhar_no` varchar(20) NOT NULL,
  `pan_no` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `lang` varchar(20) NOT NULL,
  `phno` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`first_name`, `middle_name`, `last_name`, `father_name`, `mother_name`, `date`, `emp_id`, `adhar_no`, `pan_no`, `gender`, `lang`, `phno`, `address`, `email_id`) VALUES
('', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('Munna', 'bhai', 'Zoro', 'WhitdeBeard', 'Namssi', '20-20-2020', '2334', '2012921092', '73886181', 'f', 'Englishh', '839283912', 'coorg', 'Bopanna@mail.com'),
('Brook', 'Bone', 'b', 'father', 'mother', '2021-12-02', 'b12', '3526178122', '216f2617', 'Male', 'Indian', '8891273612', 'kingdom', 'brook@gmail.com'),
('Chandan', 'Kumar', 'N', 'Chand', 'Mani', '2021-12-01', 'c18', '478171828198', '6174181817', 'Male', 'Indian', '6363167281', 'Mysore', 'chand@gmail.com'),
('Bopanna', 'Bop', 'bop', 'father', 'mother', '2021-12-03', 'd34', '89182818928', '732188', 'Male', 'Indian', '663666368', 'Coorg', 'Bop@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


package Fifthdayjava;

public class Arrayex1 {
	public static void main(String arg[]) {
		int num[]= {4,7,6,8,5,3};
		System.out.println("the element:"+num[1]);
		for(int i=0;i<num.length;i++) {
			System.out.println("the array elements are:"+num[i]);
			System.out.println(num[i]);
		}
		char ch[]= {'a','e','i','o','u'};
		for(int j=0;j<ch.length;j++) {
			System.out.println(ch[j]);
		}
		
		String st[]= {"Bopanna","Muthanna","Nowshad","Nandini"};
		for(int k=0;k<st.length;k++) {
			System.out.println(st[k]);
		}
	}
	

}

package Fifthdayjava;

public class Exceptionex2 {
	public static void main(String arg[]) {
		
		
		for(int i=0;i<=10;i++)
		{
			try {
			if(i==5) {
				i=i/0;
			}
			System.out.println(i);
		}
			catch(Exception e) {
				System.out.println("There is an exception at this point");
			}
	}

}
}

package Fifthdayjava;

public class Nullpointer {
	public static void main(String arg[]) {
		String f=null;
		try {
			if(f.equals("bop")) {
				System.out.println("its same");
			}
			else {
				System.out.println("its not same");
				
			}
		}
		catch(NullPointerException e) {
			System.out.println("its null exception");
		}
	}

}

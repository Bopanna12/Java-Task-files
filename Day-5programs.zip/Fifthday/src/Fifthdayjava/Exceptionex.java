package Fifthdayjava;

public class Exceptionex {
	public static void main(String arg[]) {
		try {
		String var=null;
		System.out.println(var.charAt(3));
	}
		catch(Exception e) {
			System.out.println("The var is null");
		}
	}

}

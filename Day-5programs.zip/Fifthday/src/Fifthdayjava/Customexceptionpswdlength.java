package Fifthdayjava;

public class Customexceptionpswdlength {
	public static void main(String arg[]) {
		String s="Bopanna";
		try {
			if(s.length()<=10)
			{
				throw new PasswordNoMatch("Password length not matched");
			}
			else {
				System.out.println("password has matched");
			}
				
		}
		catch(PasswordNoMatch p)
		{
			System.out.println(p);
		}
	}

}
class PasswordNoMatch extends Exception{
	public PasswordNoMatch(String msg) {
		super(msg);
	}
}
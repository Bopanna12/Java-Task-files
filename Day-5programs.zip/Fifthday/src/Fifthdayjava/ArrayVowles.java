package Fifthdayjava;

import java.util.Scanner;

public class ArrayVowles {
	public static void main(String arg[]) {
		int count=0;
		Scanner s=new Scanner(System.in);
		System.out.println("ehter the size of array");
		int size=s.nextInt();
		char ch[]=new char[size];
		System.out.println("enter the array elements");
		for(int i=0;i<size;i++) {
			ch[i]=s.next().charAt(0);
		}
		for(int i=0;i<size;i++) {
			if(ch[i]=='a'||ch[i]=='e'||ch[i]=='i'||ch[i]=='o'||ch[i]=='u') {
				System.out.println("vowles are:"+ch[i]);
			}
			else {
				System.out.println("these are not vowles:"+ch[i]);

			}
		}
		for(int i=0;i<size;i++) {
			if(ch[i]=='a'||ch[i]=='e'||ch[i]=='i'||ch[i]=='o'||ch[i]=='u') {
			 count++;
			}
		}
		System.out.println("the no of vowles are"+count);
	}
}

package Fifthdayjava;

public class Customexceptionex2 {
	  public static void main(String aa[]) 
	    {

	        int number=10;
	        try{
	         if(number>=10 && number<=20)
	         {
	             throw new NumberRange("Number is not in range exception");
	         }
	        }
	                 catch(NumberRange n)
	                 {
	                    System.out.println(n); 
	                 }
	    }
	}
	 

	class NumberRange extends Exception//first step 
	{
	 
	    public NumberRange(String message) {
	        super(message);

	    }

}

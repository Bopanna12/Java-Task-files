package Fifthdayjava;

public class CustomEven {
	public static void main(String arg[])throws NotEven {
		int num=3;
		try {
			if(num%2==1) {
				throw new NotEven("the Number is not even"+num);
			}
			else {
				System.out.println("the Number is even"+num);
			}
		}catch(NotEven ne) {
			System.out.println(ne);
		}
		
	}

}
class NotEven extends Exception{
	public NotEven(String msg) {
		super(msg);
	}


}

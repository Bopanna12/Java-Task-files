package Fifthdayjava;

import java.rmi.AccessException;

public class Multiplecatch {
	public static void main(String arg[]) {
		try {
		String str=null;
		System.out.println(str.length());
	}
		catch(ArithmeticException e) {
			System.out.println("the string cannot be null");
		}
		catch(Exception e) {
			System.out.println("this is for a default one");
			
		}
	}

}

package Fifthdayjava;

public class Arithematicexception {
	public static void main(String arg[]) {
		
	
	for (int i=0;i<10;i++) {
		try {
			if(i==6) {
				i=i/0;
				
			}
			System.out.println(i);
		}
		catch(ArithmeticException e) {
			System.out.println("this will be throwing an arithematic exception");
		}
		
	}

}
}
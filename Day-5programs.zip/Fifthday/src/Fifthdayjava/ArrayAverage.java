package Fifthdayjava;

import java.util.Scanner;

public class ArrayAverage {
	public static void main(String arg[]) {
		int sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the sizw of teh array");
		int size=sc.nextInt();
		int arr[]=new int[size];
		System.out.println("ehter the elements");
		for(int i=0;i<size;i++) {
			arr[i]=sc.nextInt();
		}
		for(int i=0;i<size;i++) {
			sum=sum+arr[i];
		}
		System.out.println("the average is :"+(sum/size));
	}
}

package Fifthdayjava;

import java.util.Scanner;

public class ArrayDuplicate {
	public static void main(String arg[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the size of the array :");
		int size=sc.nextInt();
		int arr[]=new int[size];
		System.out.println("Enter the array elements");
		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();
			
		}
	}

}

package Fifthdayjava;

public class CustomexceptionNegative {
	public static void main(String arg[])throws NegativeNo {
		int num=-20;
		try {
			if(num<0) {
				throw new NegativeNo("the Number is negative");
			}
			else {
				System.out.println("the Number is positive");
			}
		}catch(NegativeNo n) {
			System.out.println(n);
		}
		
	}

}
class NegativeNo extends Exception{
	public NegativeNo(String msg) {
		super(msg);
	}


}

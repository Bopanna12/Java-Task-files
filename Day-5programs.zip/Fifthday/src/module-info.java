module Fifthday {
	requires java.rmi;
}
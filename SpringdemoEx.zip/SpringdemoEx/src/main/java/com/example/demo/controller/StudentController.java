package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;
import com.example.demo.service.StudentService;

//import antlr.collections.List;


@RestController
@RequestMapping("/api")
public class StudentController {

	
	@Autowired
	StudentService service;
	
	@GetMapping("/Getstudent")
	public List<Student> getAllStudents()
	{
		return service.getAllStudents();
	}
	@PostMapping("/stdnt")
	public void saveStudent(@RequestBody Student su)
	{
		service.saveStudent(su);
	}
	@PostMapping("/deleteStudent/{id}")
	public void deleteStudent(@PathVariable String id)
	{
		service.deleteStudent(id);
	}
	
	
}

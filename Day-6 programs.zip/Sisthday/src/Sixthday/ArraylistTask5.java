package Sixthday;

import java.util.ArrayList;

public class ArraylistTask5 {
	public static void main(String arg[]) {
		ArrayList<Friend> frd=new ArrayList<>();
		Friend f1=new Friend("Yashwith","yashu",723893);
		Friend f2=new Friend("mohith","mohi",57849837);
		Friend f3=new Friend("Bopanna","Bopu",564557668);
		frd.add(f1);
        frd.add(f2);
        frd.add(f3);
		for(Friend x:frd) {
			System.out.println("name is:"+x.name+"  "+"nick name is:"+x.nickname+"  "+"Phone no is:"+x.phno);
		}
	}
}

class Friend{
	String name,nickname;
	int phno;
	public Friend(String name,String nickname, int phno) {
		super();
		this.name = name;
		this.nickname=nickname;
		this.phno=phno;
	}
	
}

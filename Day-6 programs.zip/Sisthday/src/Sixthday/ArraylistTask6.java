package Sixthday;

import java.util.ArrayList;

public class ArraylistTask6 {
	public static void main(String arg[]) {
		ArrayList<String> lang=new ArrayList<>();
		lang.add("Python");
		lang.add("java");
		lang.add("C++");
		lang.add("PHP");
		for(String r:lang) {
		System.out.println("language before removing"+" "+r);
		}
		lang.remove(2);
		for(String r:lang) {
			System.out.println("language after removing"+" "+r);
		}
	}
}

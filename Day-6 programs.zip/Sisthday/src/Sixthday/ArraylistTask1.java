package Sixthday;

import java.util.ArrayList;

public class ArraylistTask1 {
	public static void main(String arg[]) {
		ArrayList<Employee2> stm=new ArrayList<>();
		Employee2 f1=new Employee2("java","68");
		Employee2 f2=new Employee2("python","63");
		Employee2 f3=new Employee2("c","74");
		stm.add(f1);
        stm.add(f2);
        stm.add(f3);
		for(Employee2 x:stm) {
			System.out.println("language is:"+x.language+"marks is:"+x.marks);
		}
	}
}

class Employee2{
	String language,marks;
	public Employee2(String laguage, String marks) {
		super();
		this.language=language;
		this.marks=marks;
		
	}
	

}

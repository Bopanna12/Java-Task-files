package Sixthday;

import java.util.ArrayList;
import java.util.Scanner;

public class ArraylistTask3 {
	public static void main(String arg[]) {
		ArrayList<books> bo=new ArrayList<>();
		books b1=new books("Malgudi days","m6437","R.K.N","637");
		books b2=new books("Malgudi days","m6437","R.K.N","637");
		books b3=new books("Malgudi days","m6437","R.K.N","637");
		books b4=new books("Malgudi days","m6437","R.K.N","637");
		bo.add(b1);
		bo.add(b2);
		bo.add(b3);
		bo.add(b4);
		
		for(books b:bo) {
			System.out.println("Book name is:"+b.bookname+"id is"+b.bookid+"author name"+b.author+"price is"+b.price);
		}
		Scanner sc=new Scanner(System.in);
		ArrayList<marks> ma=new ArrayList<>();
		System.out.println("enter the no of students");
		int size=sc.nextInt();
		System.out.println("enter the name and marks of Student :");
		 for(int i=0;i<size;i++) {
			 String name=sc.next();
			 int m1=sc.nextInt();
			 marks m=new marks(name,m1);
			 ma.add(m);
		 }
		 for(marks m:ma) {
			 System.out.println("name is :"+m.name+"mark is:"+m.m1);
		 }
		 
		
		
		


		
	}
}
class books{
	String bookname,bookid,author,price;

	public books(String bookname, String bookid, String author, String price) {
		super();
		this.bookname = bookname;
		this.bookid = bookid;
		this.author = author;
		this.price = price;
	}
	
}
class marks{
	String name;
	int m1;
	public marks(String name,int m1) {
		super();
		this.name = name;
		this.m1 = m1;
	}
}

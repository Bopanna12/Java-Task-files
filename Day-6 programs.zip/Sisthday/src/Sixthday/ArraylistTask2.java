package Sixthday;

import java.util.ArrayList;

public class ArraylistTask2 {
	public static void main(String arg[]) {
		ArrayList<Student1> std=new ArrayList<>();
		Student1 s1=new Student1("bopanna",675,687,899);
		Student1 s2=new Student1("bopanna yashu",578,689,598);
		Student1 s3=new Student1("bop",564,557,668);
		std.add(s1);
        std.add(s2);
        std.add(s3);
		for(Student1 x:std) {
			System.out.println("name is:"+x.name+"Mark1 is:"+x.m1+"mark2 is:"+x.m2+"mark3 is:"+x.m3);
		}
	}
}

class Student1{
	String name;
	int m1;
	int m2;
	int m3;
	public Student1(String name, int m1, int m2, int m3) {
		super();
		this.name = name;
		this.m1 = m1;
		this.m2 = m2;
		this.m3 = m3;
	}
	
		
	}
	


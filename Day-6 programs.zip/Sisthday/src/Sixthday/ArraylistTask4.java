package Sixthday;

import java.util.ArrayList;

public class ArraylistTask4 {
	public static void main(String arg[]) {
		ArrayList<Studentmet> std=new ArrayList<>();
		Studentmet s1=new Studentmet("bopanna",675,687,899);
		Studentmet s2=new Studentmet("bopanna yashu",578,689,598);
		Studentmet s3=new Studentmet("bop",564,557,668);
		std.add(s1);
        std.add(s2);
        std.add(s3);
       
		for(Studentmet x:std) {
			System.out.println("name is:"+x.name+"Mark1 is:"+x.m1+"mark2 is:"+x.m2+"mark3 is:"+x.m3);
			 System.out.println(std.get(0));
		}
		try {
			
		
		std.get(2);
		}
		catch(Exception e) {
			System.out.println("ther might be an exception");
		}
		
	}
}

class Studentmet{
	String name;
	int m1;
	int m2;
	int m3;
	public Studentmet(String name, int m1, int m2, int m3) {
		super();
		this.name = name;
		this.m1 = m1;
		this.m2 = m2;
		this.m3 = m3;
	}
	
		

}

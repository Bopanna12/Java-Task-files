package Sixthday;

import java.util.ArrayList;

public class Arraylistex4 {
	public static void main(String arg[]) {
		ArrayList<Employee1> stu=new ArrayList<>();
		Employee1 e1=new Employee1("bopanna","63183681","dept");
		Employee1 e2=new Employee1("bopanna yashu","63183681","ece");
		Employee1 e3=new Employee1("bop","63183681","cse");
		stu.add(e1);
        stu.add(e2);
        stu.add(e3);
		for(Employee1 x:stu) {
			System.out.println("name is:"+x.name+"phone no is:"+x.pho+"dept is:"+x.dept);
		}
	}
}

class Employee1{
	String name;
	String pho;
	String dept;
	public Employee1(String name, String pho, String dept) {
		super();
		this.name = name;
		this.pho = pho;
		this.dept = dept;
		
	}
	
}

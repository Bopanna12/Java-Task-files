package Sixthday;

import java.util.ArrayList;

public class Arraylistex1 {
	public static void main(String arg[]) {
		ArrayList<Integer> bop=new ArrayList<>();
		bop.add(46);
		bop.add(76);
		bop.add(56);
		bop.add(464);
		bop.add(484);
		System.out.println(bop);
		ArrayList<Character> ch=new ArrayList<>();
		ch.add('g');
		ch.add('j');
		ch.add('h');
		System.out.println(ch);
		ArrayList<String> str=new ArrayList<>();
		str.add("bopanna");
		str.add("mohit");
		str.add("yashu");
		System.out.println(str);
		
		for(Integer x:bop) {
			System.out.println("the integers are :"+x);
		}
		for(Character h:ch) {
			System.out.println("the chars are :"+h);
		}
		for(String x:str) {
			System.out.println("the strings are :"+x);
		}

	}
}

package Sixthday;

import java.util.ArrayList;

public class ArrayListgetm {
	public static void main(String arg[]) {
		ArrayList<Integer> list=new ArrayList<>();
		for(int i=0;i<6;i++) {
			list.add(i);
			int index=list.get(i);
			System.out.println("elements are"+i+" "+index);
			System.out.println(list.get(0));

		}
	}
}

package newjava;

public class Table {
	public static void main(String arg[]) {
		int i=1;
		while(i<=20) {
			System.out.println(i);
			i++;
		}
	}

}

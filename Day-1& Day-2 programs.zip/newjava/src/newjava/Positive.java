package newjava;

import java.util.Scanner;

public class Positive {
	public static void main(String args[]) {
		int i;
		Scanner mo=new Scanner(System.in);
		System.out.println("enter the no");
		i=mo.nextInt();
		if(i>0) {
			System.out.println("positive no");
		}
		else {
			System.out.println("negative no");
		}
		
	}

}

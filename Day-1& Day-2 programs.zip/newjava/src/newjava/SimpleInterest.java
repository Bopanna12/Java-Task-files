package newjava;

import java.util.Scanner;

public class SimpleInterest {
	public static void main(String args[]) {
		float p,t,r;
		Scanner s=new Scanner(System.in);
		System.out.println("enter the princilple ,rate and time");
		p=s.nextFloat();
		t=s.nextFloat();
		r=s.nextFloat();
		float si;
		si=(p*t*r)/100;
		System.out.println("Simple interest is"+si);
		
		
	}

}

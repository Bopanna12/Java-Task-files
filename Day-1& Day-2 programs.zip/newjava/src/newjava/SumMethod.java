package newjava;

public class SumMethod {
	void add(float x,float y) {
		System.out.println("The sum is"+(x+y));
	}
	public static void main(String arg[]) {
		SumMethod s=new SumMethod();
		s.add(34.5f, 665.76f);
	}

}

package newjava;

public class AreaWithRet {
	public float circle(int r) {
		float p=3.14f,ca;
		ca=p*r*r;
		
		return ca;
	}
	public int square(int r) {
		int sa;
		sa=r*r;
		
		return sa;
	}
	public int rectangle(int l,int b) {
		int ra;
		ra=l*b;
		
		return ra;
	}
	public static void main(String args[]) {
		AreaWithRet ar=new AreaWithRet();
		float a=ar.circle(5);
		int b=ar.square(6);
		int c=ar.rectangle(4,6);
		System.out.println("Area of Circle is"+a);
		System.out.println("Area of Square is"+b);
		System.out.println("Area of Rectangle is"+c);
		
	}

}

package newjava;

public class TableDoW {
	public static void main(String arg[]) {
		int i=1;
		do {
			System.out.println(i);
			i++;
			
		}
		while(i<=20);
	
	}

}

package newjava;

public class Static {

}

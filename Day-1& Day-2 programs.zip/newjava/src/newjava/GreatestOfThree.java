package newjava;

import java.util.Scanner;

public class GreatestOfThree {
	public static void main(String args[]) {
		int a , b,c;
		Scanner bc=new Scanner(System.in);
		System.out.println("enter three no");
		a=bc.nextInt();
		b=bc.nextInt();
		c=bc.nextInt();
		if(a>b && a>c) {
			System.out.println("a is greater");
			
		}
		else if(b>c && b>a) {
			System.out.println("b is greater ");
			
		}
		else {
			System.out.println("c is greater");
		}
	}

}

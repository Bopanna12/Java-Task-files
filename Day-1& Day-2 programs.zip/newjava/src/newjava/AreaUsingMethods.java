package newjava;

public class AreaUsingMethods {
	void circle(int r) {
		float p=3.14f,ca;
		ca=p*r*r;
		System.out.println("Area of Circle is"+ca);
	}
	void square(int r) {
		int sa;
		sa=r*r;
		String sz;
		System.out.println("Area of Circle is"+sz);
	}
	void rectangle(int l,int b) {
		int ra;
		ra=l*b;
	}
	public static void main(String args[]) {
		AreaUsingMethods ar=new AreaUsingMethods();
		ar.circle(5);
		ar.square(6);
		ar.rectangle(4,6);
		
	}

}

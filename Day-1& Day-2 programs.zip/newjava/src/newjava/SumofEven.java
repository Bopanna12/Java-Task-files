package newjava;

public class SumofEven {
	public static void main(String args[]) {
		int n = 0,i;
	    for(i=0;i<=100;i++) {
	    	if(i%2==0) {
	    		n=n+i;
	    		
	    		
	    	}
	    	
	    }
	    System.out.println(n);
	}

}

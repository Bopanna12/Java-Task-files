package newjava;

public class MethodExample {


	    void table(int x)
	    {
	    for(int i=1;i<=10;i++)
	        System.out.println(x*i);

	    }

	    public static void main(String aa[])
	    {
	         System.out.print("Thankyou!!!");
	         Test t=new Test();

	         t.table(9);
	}


	}



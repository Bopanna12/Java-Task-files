package newjava;

import java.util.Scanner;

public class Areacir {
	public static void main(String args[]) {
		float w;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the radius");
		
		w=s.nextFloat();
		
		float pi=3.142f, area;
		
		area=(w*w*pi);
		System.out.println(area);

}

}

package newjava;

import java.util.Scanner;

public class GreatestOfFourNO {
	public static void main(String args[]) {
		int a , b,c,d;
		Scanner dc=new Scanner(System.in);
		System.out.println("enter four no");
		a=dc.nextInt();
		b=dc.nextInt();
		c=dc.nextInt();
		d=dc.nextInt();
		if(a>b && a>c && a>d) {
			System.out.println("a is greater");
			
		}
		else if(b>c && b>a && b>d) {
			System.out.println("b is greater ");
			
		}
		else if(c>a && c>b && c>d) {
			System.out.println("c is greater ");
			
		}
		else {
			System.out.println("d is greater");
		}
	}


}

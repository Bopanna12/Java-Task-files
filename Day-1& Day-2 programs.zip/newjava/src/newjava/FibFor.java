package newjava;

public class FibFor {
	public static void main(String args[]) {
		xjx
	}


}

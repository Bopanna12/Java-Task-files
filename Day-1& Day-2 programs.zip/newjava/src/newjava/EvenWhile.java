package newjava;

public class EvenWhile {
	public static void main(String args[]) {
		int i=0,n=0;
		while(i<=100 && i%2==0) {
			n=n+i;
			i++;
			
		}
		
	}
	}


package newjava;

import java.util.Scanner;

public class Even {
	public static void main() {
	int a;
	Scanner p=new Scanner(System.in);
	System.out.println("Enter the number");
	a=p.nextInt();
	if(a%2==0) {
		System.out.println("Even no");
	}
	else
	{
		System.out.println("not even");
	}
	}
	

}

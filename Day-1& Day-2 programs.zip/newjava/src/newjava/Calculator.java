package newjava;

import java.util.Scanner;

public class Calculator {
	public static void main(String args[]) {
		Scanner ca=new Scanner(System.in);
		char ch;
		do {
		System.out.println("Enter the first no");
		int a=ca.nextInt();
		System.out.println("enter the second no");
		int b=ca.nextInt();
		System.out.println("Select your choice");
		System.out.println("Enter \n1 for Addition\n 2 for subtraction\n 3 for multiplication and\n 4 for division");
		int c=ca.nextInt();
		if (c==1) {
			int x=a+b;
			System.out.println("the sum is "+x);
			
		}
		else if(c==2) {
			int x=a-b;
			System.out.println("the sub is "+x);
			
			
		}
		else if(c==3) {
			int x=a*b;
			System.out.println("the sub is "+x);
			}
		else  {
			int x=a/b;
			System.out.println("the sub is "+x);
		}
		System.out.println("do you want to continue:(y/n)?");
		 ch=ca.next().charAt(0);
		}
		while(ch=='y'||ch=='Y');
		System.out.println("thankyou!");
		
		
		
	}
}

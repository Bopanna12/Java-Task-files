package newjava;

public class PositiveOrNegative {
	public int positive(int n) {
		if(n>0) {
			System.out.println("the no is positive");
		}
		else {
			System.out.println("the no is negative");
		}
		return n;
		}
		public static void main(String argd[]) {
			PositiveOrNegative e=new PositiveOrNegative();
			int t=e.positive(-3);
			System.out.println(t);
			
		}

}

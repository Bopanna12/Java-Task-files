package newjava;

import java.util.Scanner;

public class Arearec {
	public static void main(String args[]) {
		float l,w;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter length and breadth numbers");
		l=s.nextFloat();
		w=s.nextFloat();
		
		float area;
		area=(l*w);
		System.out.println(area);

}
}

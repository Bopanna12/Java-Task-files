package newjava;

public class MethodWithoutreturntype {
	public class Test {



	     void add(int x,int y)
	    {
	     System.out.print(x+y);

	    }

	     void add(float x,float y)
	    {
	        System.out.print(x+y);

	    }

	    public static void main(String aa[])
	    {
	         System.out.print("Thankyou!!!");
	         Test t=new Test();

	         t.add(5,2);
	}


	}

}

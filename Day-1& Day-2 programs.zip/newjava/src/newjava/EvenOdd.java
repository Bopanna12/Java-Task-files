package newjava;

public class EvenOdd {
	public int evenOdd(int n) {
	if(n%2==0) {
		System.out.println("it is even");
	}
	else {
		System.out.println("not even");
	}
	return n;
	}
	public static void main(String argd[]) {
		EvenOdd e=new EvenOdd();
		int t=e.evenOdd(3);
		System.out.println(t);
		
	}

}

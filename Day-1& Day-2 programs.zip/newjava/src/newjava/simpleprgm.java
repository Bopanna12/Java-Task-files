package newjava;

public class simpleprgm {
	public static void main(String args[]) {
		String variable="Bopanna";
		String var1="java";
		
		int age=22;
		System.out.println("My name is"+ variable);
		System.out.println("I am learning"+ var1+"technology");
		System.out.println("My age is" + age);
	}

}

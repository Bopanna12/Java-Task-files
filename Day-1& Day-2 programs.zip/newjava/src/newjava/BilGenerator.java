package newjava;

import java.util.Scanner;

public class BilGenerator {
	public static void main(String args[]) {
		int x=400,p;
		Scanner bi=new Scanner(System.in);
		System.out.println("enter the no of calls made");
		x=bi.nextInt();
		if(x>=301)
		{
            p=100*1+200*2+(x-300)*3;
			System.out.println("cost of the call is free");
		}
		else if(x>=101 && x<=200) {

			System.out.println("Call cost is 1Rs/call");
		}
		else if(x>=201 && x<=300) {

			System.out.println("Call cost is 2Rs/call");
	}
		else {

			System.out.println("call cost 3Rs/call");
		}
	}
	

}

package newjava;

public class WithRetSum {
	public int sum() {
		int c=1;
		for(int i=1;i<=100;i++)
		{
			 c=c+i;
		}
		return c;
	}
	public static void main(String arg[]) {
		WithRetSum r=new WithRetSum();
		int t=r.sum();
		System.out.println(t);
	}

}

package newjava;

import java.util.Scanner;

public class Factorial {
   public static void main(String args[])
   {
	   int n,i,a = 0;
	   Scanner fc=new Scanner(System.in);
	   System.out.println("Enter a no ");
	   n=fc.nextInt();
	   for(i=n;n>=1;i--) {
		   a=n*(n-1);
	   }
	   System.out.println("factorial is"+a);
   }
   
}

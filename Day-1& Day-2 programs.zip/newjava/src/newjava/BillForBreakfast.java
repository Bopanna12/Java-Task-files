package newjava;

import java.util.Scanner;

public class BillForBreakfast {
	 public static void main(String aa[])
	    {
	        
	        Scanner sc=new Scanner(System.in); 
	        char ch = 0;
	        int price=0;
	        do {
	        
	        System.out.print("Select your oder :\n1.Breakfast\n2.Lunch\n3.Dinner");
	        int op=sc.nextInt();
	        if(op==1)
	        {
	        	
	            System.out.print("Items for breakfast are:\n1.Tea/Coffe-30Rs\n2.Rice Pulav-50Rs\n3.Dosa-40Rs");
	            int a=sc.nextInt();
	            
	            if(a==1) {
	            	do{
	            
	            
	            	System.out.println("Do you want to order someting more (y/n);");
	            	price=30;
	            	ch=sc.next().charAt(0);
	            
	            	}
	            while(ch=='y'||ch=='Y');
	            	System.out.println("THANKYOU\n");
	            System.out.println("the total bill is"+price);
	            }
	            else if(a==2) {
	            	do {
	            		System.out.println("Do you want to order someting more (y/n);");
		            	price=price+50;
		            	ch=sc.next().charAt(0);

	            		
	            	}
	            	 while(ch=='y'||ch=='Y');
            	System.out.println("THANKYOU\n");
            System.out.println("the total bill is"+price);
	            }
	            
	            else {
	            	do {
	            		System.out.println("Do you want to order someting more (y/n);");
		            	price=price+40;
		            	ch=sc.next().charAt(0);

	            		
	            	}
	            	 while(ch=='y'||ch=='Y');
            	System.out.println("THANKYOU\n");
            System.out.println("the total bill is"+price);
	            }


	             	
	        }
	        	
	        System.out.print("Do you want to order something more?(yes/no)");
	        ch=sc.next().charAt(0);
	        }
	        while(ch=='y'||ch=='Y');
	        System.out.print("Thankyou!!!");
	        System.out.println("the total bill is"+price);
        	
	}

}

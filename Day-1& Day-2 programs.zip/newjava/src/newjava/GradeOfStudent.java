package newjava;

import java.util.Scanner;

public class GradeOfStudent {
	public static void main(String args[]) {
		Scanner go=new Scanner(System.in);
		System.out.println("enter the marks");
		int a;
		a=go.nextInt();
		if(a>=80) {
			System.out.println("scored a grade");
			
		}
		else if(a>=60 && a<=80) {
			System.out.println("scored b grade");
		}
		else
		{
			System.out.println("scored c grade");
		}
	}
	

}

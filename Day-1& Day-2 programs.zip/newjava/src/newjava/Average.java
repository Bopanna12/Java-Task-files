package newjava;

import java.util.Scanner;

public class Average {
	public static void main(String args[]) {
		float a,b,c,d,e;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter 5 numbers");
		a=s.nextFloat();
		b=s.nextFloat();
		c=s.nextFloat();
		d=s.nextFloat();
		e=s.nextFloat();
		float avg;
		avg=(a+b+c+d+e)/5;
		System.out.println(avg);
	}

}

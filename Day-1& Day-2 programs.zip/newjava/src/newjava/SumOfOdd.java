package newjava;

public class SumOfOdd {
	public static void main(String args[]) {
		int n = 0,i;
	    for(i=0;i<=50;i++) {
	    	if(i%2==1) {
	    		n=n+i;
	    		
	    		
	    	}
	    	
	    }
	    System.out.println(n);
	}

}

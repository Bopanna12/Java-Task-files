package newjava;

import java.util.Scanner;

public class Areasqr {
	public static void main(String args[]) {
		float l;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the area numbers");
		l=s.nextFloat();
		
		
		float area;
		area=(l*l);
		System.out.println(area);

}

}

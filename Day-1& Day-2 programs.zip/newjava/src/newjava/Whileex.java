package newjava;

public class Whileex {
	 public static void main(String aa[])
	    {
	    int a=21;
	    while(a>=20)
	    {
	        System.out.print("working!!!");
	        a--;
	    }
	}

}

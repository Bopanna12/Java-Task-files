package newjava;

public class NumberDivisibleBy {
	public static void main(String args[]) {
		int n = 0,i;
	    for(i=0;i<=1000;i++) {
	    	if(i%3==0 && i%9==0) {
	    		n=n+i;
	    		
	    		
	    	}
	    	
	    }
	    System.out.println(n);
	}

}

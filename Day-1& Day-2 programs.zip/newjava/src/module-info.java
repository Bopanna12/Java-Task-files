module javatraining {
}
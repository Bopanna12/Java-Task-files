package thirdday;

import java.util.Scanner;

public class StudentEx {
	public static void main(String args[]) {
		Result r=new Result();
		r.readDetails() ;
		r.readMarks();
		r.displayDetails();
		r.displayMarks();
		r.calculateResult();
		r.displayResult();
		
	}
	

}
	class multi {
	Scanner sc=new Scanner(System.in);
	int studentid;
	String phoneno, studentname;
	
	void readDetails() {
		System.out.println("enter the id");
		studentid=sc.nextInt();
		System.out.println("enter the phoneno");
		phoneno=sc.next();
		System.out.println("enter the name");
		studentname=sc.next();
		
	}
	void displayDetails() {
		System.out.println("id is :"+studentid);
		System.out.println("name is :"+studentname);
		System.out.println("phone no is :"+phoneno);

	}

}
class Marks1 extends multi{
	int m1,m2,m3;
	
	void readMarks() {
		System.out.println("enter three marks");
		m1=sc.nextInt();
		m2=sc.nextInt();
		m3=sc.nextInt();
		}
	void displayMarks() {
		
		System.out.println("marks of chem is"+m1);
		System.out.println("marks of bio is"+m2);
		System.out.println("marks of mat is"+m3);
	}
}

class Result extends Marks1{
	int totalmarks;
	float percentage;
	String grade;
	
	void calculateResult() {
		totalmarks=m1+m2+m3;
		percentage=((totalmarks*100)/300);
		if(percentage>80) {
		grade="First Class";
		}
		else if(percentage>=60 && percentage<=79) {
			grade="Second Class";
		}
		else if(percentage>=40 && percentage<=59) {
			grade="Third Class";

		}
		else {
			grade="Fail";

		}
		
	}
	
	
	void displayResult() {
		System.out.println("Totalmarks are"+totalmarks);
		System.out.println("Percentage is"+percentage);
		System.out.println("Grade is"+grade);
		
	}

}


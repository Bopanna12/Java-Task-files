package thirdday;

public class Perimeter {
	
	//	String name;
	  //  Perimeter(String name){
		//this.name=name;
	//	System.out.println("The name of the Student is "+name);
	//	}
	//	Perimeter(){
	//	System.out.println("The name of the Student is unknown ");
	//	}
	
	
	
	
	class student{
		String name;
		student(String n){
			name = n
		}
	}
		}





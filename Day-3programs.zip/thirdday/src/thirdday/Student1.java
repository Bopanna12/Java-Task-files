package thirdday;

import java.util.Scanner;

public class Student1{
	Scanner sc=new Scanner(System.in);
	int studentid;
	String phoneno, studentname;
	
	void readDetails() {
		System.out.println("enter the id");
		studentid=sc.nextInt();
		System.out.println("enter the phoneno");
		phoneno=sc.next();
		System.out.println("enter the name");
		studentname=sc.next();
		
	}
	void displayDetails() {
		System.out.println("id is :"+studentid);
		System.out.println("name is :"+studentname);
		System.out.println("phone no is :"+phoneno);

	}
}
	class Mpcmarks extends Student1{
		int physicsmarks,chemmarks ,mathsmarks;
		
		void ReadMPCmarks() {
			System.out.println("enter marks for maths ");
			mathsmarks=sc.nextInt();
			System.out.println("enter marks for Physics ");
			physicsmarks=sc.nextInt();
			System.out.println("enter marks chemistry ");
			chemmarks=sc.nextInt();
			
		}
		void displayMPCmarls() {
			System.out.println("Maths :"+mathsmarks);
			System.out.println("Physics :"+physicsmarks);
			System.out.println("Chemistry :"+chemmarks);
			
		}
		
		
	}
	class Cecmmarks extends Student1{
		int commarks,ecomarks ,civmarks;
		
		void ReadMPCmarks() {
			System.out.println("enter marks for comerce ");
			commarks=sc.nextInt();
			System.out.println("enter marks for  economy ");
			ecomarks=sc.nextInt();
			System.out.println("enter marks civics ");
			civmarks=sc.nextInt();
			
		}
		void displayMPCmarls() {
			System.out.println("commerce:"+commarks);
			System.out.println("Economy :"+ecomarks);
			System.out.println("civics :"+civmarks);
			
		}
		
		
	

	public static void main(String arg[]) {
		Mpcmarks m=new Mpcmarks();
		Cecmmarks m2=new Cecmmarks();
		m.readDetails();
		m.displayDetails();
		m.ReadMPCmarks();
		m.displayMPCmarls();
		m2. ReadMPCmarks();
		m2.displayMPCmarls();
		}
	}
	



package thirdday;

import java.util.Scanner;

public class Student {
		String studentid;
		String studentname;
		String phoneno;
		Scanner s=new Scanner(System.in);
		
		void readDetails() {
			System.out.println("enter id , name and phoneno");
			studentid=s.next();
			studentname=s.next();
			phoneno=s.next();
			
		}
		void displayDetails() {
			System.out.println("Student id is"+studentid);
			System.out.println("Student name is"+studentname);
			System.out.println("Student phone no is"+phoneno);
			}
		}
	
		class Marks extends Student{
			int m1,m2,m3;
		
		void readMarks() {
			System.out.println("enter three marks");
			m1=s.nextInt();
			m2=s.nextInt();
			m3=s.nextInt();
			}
		void displayMarks() {
			
			System.out.println("marks of chem is"+m1);
			System.out.println("marks of bio is"+m2);
			System.out.println("marks of mat is"+m3);
		}
		
	
		public static void main(String args[]) {
			Marks m=new Marks();
			m.readDetails();
			m.displayDetails();
			m.readMarks();
			m.displayMarks();
			
			
		}
	

}

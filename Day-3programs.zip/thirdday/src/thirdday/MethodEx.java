package thirdday;

public class MethodEx {
	String name, rollno;
	void setName(String name) {
		
		this.name=name;
	}
	void setRollno(String rollno) {
		
		this.rollno=rollno;
	}																//try for viceversa
     String getName() {
	return name;
		
	}
	String getRollno() {
		return rollno;
	}
	public static void main(String args[]) {
		MethodEx me=new MethodEx();
		me.setName("Bopanna");
		me.setRollno("22");
		System.out.println(me.getName()+"  "+me.getRollno());
		
	}

}

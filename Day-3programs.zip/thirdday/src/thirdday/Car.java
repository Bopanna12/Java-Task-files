package thirdday;

public class Car {
	String brandname,price;

	
	Car(String x,String y){
		brandname=x;
		price=y;
	}
	
	String getDetails() {
		return brandname +" "+price;
	}

public static void main(String arg[])
{
	Car c=new Car("Audi","61278");
	System.out.println(c.getDetails());
	}
}

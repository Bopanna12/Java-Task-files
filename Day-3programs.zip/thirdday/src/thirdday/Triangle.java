package thirdday;

//import java.util.Scanner;

public class Triangle {
		//int l,b,h;
	//	Triangle(){
		//System.out.println("Enter the sides of triangle");
	//	Scanner s=new Scanner(System.in);

	//	l=s.nextInt();
	//	b=s.nextInt();
	//	h=s.nextInt();
	//	int p=l+b+h;
	//	int s2=p/2;
	//	double sq =(s2*(s2-l)*(s2-b)*(s2-h));
	//	double area=Math.sqrt(sq);
	//	System.out.println("Area is: "+area+" Perimeter is: "+p);

	//	}
	
	
	 int a,b,c,ar,er;
	 Triangle(){
		 a=10;
		 b=20;
		 c=30;
		  ar=(a*b)/2;
		  er=a+b+c;
		 
	 }
	 int area() {
		 return ar;
		 
	 }
	 int perimeter() {
		 return er;
	 }
	 public static void main(String args[]) {
		 Triangle t=new Triangle();
		 System.out.println("area is"+t.area());
		 System.out.println("perimeter is"+t.perimeter());
	 }



		}


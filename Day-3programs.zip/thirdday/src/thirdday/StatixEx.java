package thirdday;

public class StatixEx {
	

}

package thirdday;

public class Bankdetails {

}

package thirdday;

public class Area {

	public static void main(String args[]) {
		circle c=new circle(5);
		System.out.println("area of circle is"+c.getArea());
		Square s=new Square(5);
		System.out.println("area of circle is"+s.getArea1());
		
		}
}
	
	class circle{
		float radius;
		circle(float r){
			radius=3.14f*r*r;
		}
		float getArea() {
			return radius;
		}
	}
	class Square{
	     int  side;
		Square(int s){
			side=s*s;
		}
		int getArea1() {
			return side;
		}
	}
	



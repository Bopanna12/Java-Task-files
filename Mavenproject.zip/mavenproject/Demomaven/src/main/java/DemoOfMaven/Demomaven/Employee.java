package DemoOfMaven.Demomaven;

public class Employee {
String name,id,salary,address;

public Employee() {
	
}

public Employee(String name, String id, String salary, String address) {
	
	this.name = name;
	this.id = id;
	this.salary = salary;
	this.address = address;
}
void display() {
	System.out.println("name is:"+name+"id is:"+id+"salary is:"+salary+"address is:"+address);
}
}

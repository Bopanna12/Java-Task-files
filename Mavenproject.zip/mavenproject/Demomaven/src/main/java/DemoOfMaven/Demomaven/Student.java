package DemoOfMaven.Demomaven;

public class Student {
	String id,publisher,price;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	void display() {
		System.out.println("Book id is:"+id+" "+"Publisher name is :"+publisher+" "+"Book price is"+price);
	}

	
}

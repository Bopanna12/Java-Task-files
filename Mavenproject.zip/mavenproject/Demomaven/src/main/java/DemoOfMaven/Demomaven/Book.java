package DemoOfMaven.Demomaven;

public class Book {
String name,roll;

public Book() {
	
}

public Book(String name, String roll) {
	this.name = name;
	this.roll = roll;
}
void display() {
	System.out.println("name is :"+name+"Roll no is :"+roll);
}
}

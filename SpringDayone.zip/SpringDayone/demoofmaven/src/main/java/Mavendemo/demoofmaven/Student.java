package Mavendemo.demoofmaven;

public class Student {

}

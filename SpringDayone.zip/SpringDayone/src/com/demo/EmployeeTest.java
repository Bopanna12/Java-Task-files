package com.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeTest {
	public static void main(String arg[]) {

	ApplicationContext context=new ClassPathXmlApplicationContext("Employee.xml"); 
	Employee e=(Employee)context.getBean("e1");
	e.display();

}
}

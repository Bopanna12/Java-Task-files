package com.demo;

public class Book {
	String bookId,bookPublisher,bookPrice;

	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public String getBookPublisher() {
		return bookPublisher;
	}

	public void setBookPublisher(String bookPublisher) {
		this.bookPublisher = bookPublisher;
	}

	public String getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(String bookPrice) {
		this.bookPrice = bookPrice;
	}
	void display() {
		System.out.println("Book id is:"+bookId+" "+"Publisher name is :"+bookPublisher+" "+"Book price is"+bookPrice);
	}
}

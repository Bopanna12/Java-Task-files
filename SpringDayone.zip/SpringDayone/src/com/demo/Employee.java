package com.demo;

public class Employee {
	String empId,address,empname;
	int salary;
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	void display() {
		System.out.println("Employee id is:"+empId+" "+"employee address is :"+address+" "+"salary  is"+salary+"emp name"+empname);
		
	}
}

package com.example.demo.controller1;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model1.Student;
import com.example.demo.service1.StudentService;

@RestController
@RequestMapping("/ini")
public class StudentController {
	
	@Autowired
	StudentService service;
	
	
	@PostMapping( "/addstudent")
	public void addStudent(@RequestBody Student st) 
	{
		service.addStudent(st);
	}
	@GetMapping("/Getstudents")
	public List<Student> getAllStudents()
	{
		return service.getAllStudents();
		
	}
	@GetMapping("/Getonestudent/{id}")
	public Optional<Student> getOneStudent(@PathVariable String id)
	{
		return service.getOneStudent(id);
		
	}
	@PostMapping("/deletestudent/{id1}")
	public void deleteStudent(@PathVariable String id1)
	{
		service.deleteStudent(id1);
	}
	@PostMapping("updateuser/{id}")
	public void updateStudent(@PathVariable String id, @RequestBody Student s)
	{
		service.updateStudent(id,s);
	}
}

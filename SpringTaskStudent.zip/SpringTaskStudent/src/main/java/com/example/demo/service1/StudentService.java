package com.example.demo.service1;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model1.Student;
import com.example.demo.repository1.StudentRepository;

@Service
public class StudentService {
	@Autowired
	StudentRepository repository;
	
	public void addStudent(Student s)
	{
		repository.save(s);
	}
	public List<Student> getAllStudents()
	{
		return repository.findAll();
		
	}
	public Optional<Student> getOneStudent(String i)
	{
		return repository.findById(i);
	}
	public void deleteStudent(String j)
	{
		repository.deleteById(j);
	}
	public void updateStudent(String id,Student s)
	{
		repository.findById(id);
		repository.save(s);
	}
}

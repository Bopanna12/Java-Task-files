package Eightd;

public class ThisDemo {
}

	class SimpleMethod {

	    int age;
	    SimpleMethod(int age){
	        age = age;
	    }

	    public static void main(String[] args) {
	        SimpleMethod obj = new SimpleMethod(27);
	        System.out.println("obj.age = " + obj.age);
	        
	    }
	}
	


package Eightd;

public class SuperDemo {
	
}
class Shirt{  
	String color="white";  
	}  
class Tshirt extends Shirt{  
	String color="black";  
	void printColor(){  
		System.out.println(color);  
		System.out.println(super.color);
		}  
	}  
class TestSuper1{  
	public static void main(String args[]){  
		Tshirt t=new Tshirt();  
		t.printColor();  
		}
	}  

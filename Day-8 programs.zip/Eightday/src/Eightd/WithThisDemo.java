package Eightd;

public class WithThisDemo {
}
	class AgeofPerson {

	    int age;
	    AgeofPerson(int age){
	        this.age = age;
	    }

	    public static void main(String[] args) {
	        AgeofPerson obj = new AgeofPerson(25);
	        System.out.println("obj.age = " + obj.age);
	    }
	}


